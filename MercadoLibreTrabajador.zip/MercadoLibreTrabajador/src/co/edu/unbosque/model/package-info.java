/**
 * Este paquete tiene como proposito la administración de los datos, contiene las clase mayor llamada producto la cual hereda las diferentes clases a implementar dentro del proyecto 
 * sus atributos tanto generales como propios, además de eso cuanta con la clase Model Facade donde se incializan todos los DAO 
 * para su buen funcionamiento. 
 */
package co.edu.unbosque.model;