/**
 * Este paquete contiene las clases relacionadas con el buen funcionamiento del CRUD, además cuenta con la clase 
 * necesaria en el llamado y funcionamiento de la creación de archivos.
 * 
 */
package co.edu.unbosque.model.persistence;