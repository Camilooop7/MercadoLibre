package co.edu.unbosque.util.exception;

public class IsBlackException extends Exception {
	public IsBlackException() {
		super("No puede quedar en blanco este espacio");
	}

}
