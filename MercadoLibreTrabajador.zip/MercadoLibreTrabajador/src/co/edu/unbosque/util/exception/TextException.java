package co.edu.unbosque.util.exception;

public class TextException extends Exception{
	public TextException() {
		super ("Solo puede contener letras.");
	}
}
