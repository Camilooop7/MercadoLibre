package co.edu.unbosque.util.exception;

public class ImageException  extends Exception{
public ImageException() {
super("Debe selecionar una imagen");
	// TODO Auto-generated constructor stub
}
}
