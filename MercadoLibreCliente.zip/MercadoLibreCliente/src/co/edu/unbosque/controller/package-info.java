/**
 * Este paquete se encarga de controlar y recibir las acciones que 
 * esta ejecutando el usuario al momento de la inicialización del aplicativo.
 * Contiene la clase para chekear las excepciones y la creación de suparametros y funciones. 
 */
package co.edu.unbosque.controller;