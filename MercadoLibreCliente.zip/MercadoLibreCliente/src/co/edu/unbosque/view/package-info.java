/**
 * Este paquete contiene las clases relacionadas con la interfaz gráfica de usuario
 * Incluye paneles, botones, y otros componentes
 * visuales necesarios para el funcionamiento visual correcto del aplicativo.
 */
package co.edu.unbosque.view;