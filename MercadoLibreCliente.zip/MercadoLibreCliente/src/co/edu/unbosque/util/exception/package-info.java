/**
 * Este paquete contiene las clases relacionadas con la creación de las diversas excepciones 
 * las cuales son utilizadas y llamadas dentro del controller para su buen funcionamiento.
 */
package co.edu.unbosque.util.exception;
